# react-native-maps 

To run examples:

```bash
"start": "expo start",
"android": "expo start --android",
"ios": "expo start --ios",
"web": "expo start --web",
"eject": "expo eject"
```


MapView Events
The <MapView /> component and its child components have several events that you can subscribe to. This example displays some of them in a log as a demonstration.